/* =========================================================================
   模擬会計ソフト  Service Worker
   ・アプリのファイルを端末に保存し、インターネットがなくても動くようにします
   ・ファイルを差しかえたときは、下の APP_VERSION の数字を変えてください
     （数字を変えないと、生徒の端末に新しい版が届きません）
   ========================================================================= */
const APP_VERSION = "1.0.0";
const CACHE = "mogi-kaikei-" + APP_VERSION;

const ASSETS = [
  "./",
  "./index.html",
  "./teacher.html",
  "./manifest-student.webmanifest",
  "./manifest-teacher.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-180.png",
  "./icons/icon-maskable-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    /* cache:"reload" で、必ずサーバーから最新を取り直して保存する */
    await Promise.all(ASSETS.map(async url => {
      try {
        const res = await fetch(new Request(url, { cache: "reload" }));
        if (res && (res.ok || res.type === "opaque")) await cache.put(url, res);
      } catch (e) { /* 1つ取れなくても止めない */ }
    }));
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys.filter(k => k.startsWith("mogi-kaikei-") && k !== CACHE)
          .map(k => caches.delete(k))
    );
    if (self.registration.navigationPreload) {
      try { await self.registration.navigationPreload.disable(); } catch (e) {}
    }
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  let url;
  try { url = new URL(req.url); } catch (e) { return; }
  if (url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cached = await caches.match(req, { ignoreSearch: true });
    if (cached) {
      /* 表示はすぐ返し、裏側で静かに新しいものを取りに行く */
      event.waitUntil(refresh(req));
      return cached;
    }
    try {
      return await refresh(req);
    } catch (err) {
      if (req.mode === "navigate") {
        const fallback = await caches.match("./index.html");
        if (fallback) return fallback;
      }
      return new Response(
        "<!doctype html><meta charset='utf-8'><p style='font-family:sans-serif;padding:2em'>" +
        "このページは保存されていません。一度インターネットにつないで開き直してください。</p>",
        { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } }
      );
    }
  })());
});

async function refresh(req) {
  const res = await fetch(req);
  if (res && res.ok) {
    const cache = await caches.open(CACHE);
    cache.put(req, res.clone());
  }
  return res;
}

self.addEventListener("message", event => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
  if (event.data === "VERSION" && event.source) event.source.postMessage({ version: APP_VERSION });
});
